@echo off
setlocal
cd /d "%~dp0"
if not exist "runtime\node.exe" (
  echo Missing runtime\node.exe. Extract the complete package first.
  pause
  exit /b 1
)
"runtime\node.exe" --disable-warning=ExperimentalWarning "launcher.cjs" start %*
if errorlevel 1 (
  echo Operation failed. See the message above.
  pause
  exit /b 1
)
endlocal
